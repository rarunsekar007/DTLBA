import traci
import random
import hashlib
import csv
import os

# --------- FORCE GRAPH BACKEND (NO GUI REQUIRED) ----------
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# -----------------------------
# PARAMETERS
# -----------------------------
q = 7557773
OUTPUT_FILE = r"D:\sumo_projects\first_sim\simulation_log.csv"

# -----------------------------
# BASIC FUNCTIONS
# -----------------------------
def H(data):
    return hashlib.sha256(str(data).encode()).hexdigest()

def Cha(x):
    return 0 if (-q//4 <= x <= q//4) else 1

def Mod2(v, b):
    return ((v + b * ((q-1)//2)) % q) % 2

# -----------------------------
# TA SETUP
# -----------------------------
def TA_setup():
    sTA = random.randint(1, q)
    a = random.randint(1, q)
    e = random.randint(1, q)
    pTA = (a * sTA + e) % q
    return a, sTA, pTA

# -----------------------------
# VEHICLE REGISTRATION
# -----------------------------
def register_vehicle(a, sTA, vid):
    si = random.randint(1, q)
    ei = random.randint(1, q)
    pi = (a * si + ei) % q

    Ki = random.randint(1, q)
    DIDi = H(str(vid) + str(sTA) + str(Ki))

    return {"VID": vid, "DID": DIDi}

# -----------------------------
# GRAPH GENERATION
# -----------------------------
def plot_graph():
    print("\nGenerating graphs...")

    try:
        steps = []
        speeds = []
        vehicles = []
        throughput = []

        with open(OUTPUT_FILE, "r") as f:
            reader = csv.DictReader(f)
            for row in reader:
                steps.append(int(row["Step"]))
                vehicles.append(int(row["Vehicle_Count"]))
                speeds.append(float(row["Avg_Speed"]))
                throughput.append(float(row["Throughput"]))

        print("Data loaded successfully")

        # SPEED GRAPH
        plt.figure()
        plt.plot(steps, speeds)
        plt.xlabel("Time Step")
        plt.ylabel("Average Speed")
        plt.title("Speed vs Time")
        plt.grid()
        plt.savefig(r"D:\sumo_projects\first_sim\speed.png")
        print("Saved speed.png")

        # VEHICLE DENSITY
        plt.figure()
        plt.plot(steps, vehicles)
        plt.xlabel("Time Step")
        plt.ylabel("Vehicle Count")
        plt.title("Vehicle Density")
        plt.grid()
        plt.savefig(r"D:\sumo_projects\first_sim\density.png")
        print("Saved density.png")

        # THROUGHPUT
        plt.figure()
        plt.plot(steps, throughput)
        plt.xlabel("Time Step")
        plt.ylabel("Throughput")
        plt.title("Throughput vs Time")
        plt.grid()
        plt.savefig(r"D:\sumo_projects\first_sim\throughput.png")
        print("Saved throughput.png")

        print("All graphs generated successfully!\n")

    except Exception as e:
        print("Graph error:", e)

# -----------------------------
# MAIN SIMULATION
# -----------------------------
def run():
    print("Current Directory:", os.getcwd())
    print("Starting SUMO...")

    try:
        traci.start([
            "sumo-gui",
            "-n", "mynet.net.xml",
            "-r", "routes.rou.xml",
            "--start"
        ])
    except Exception as e:
        print("SUMO start error:", e)
        return

    print("SUMO started successfully")

    a, sTA, pTA = TA_setup()
    vehicles = {}

    # Ensure directory exists
    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)

    try:
        f = open(OUTPUT_FILE, "w", newline="")
        writer = csv.writer(f)
        writer.writerow(["Step", "Vehicle_Count", "Avg_Speed", "Throughput"])

        print("CSV file created at:", OUTPUT_FILE)

        step = 0
        MAX_STEPS = 200

        while step < MAX_STEPS:
            traci.simulationStep()

            veh_ids = traci.vehicle.getIDList()
            vehicle_count = len(veh_ids)

            total_speed = 0

            for vid in veh_ids:
                if vid not in vehicles:
                    vehicles[vid] = register_vehicle(a, sTA, vid)

                speed = traci.vehicle.getSpeed(vid)
                total_speed += speed

            avg_speed = total_speed / vehicle_count if vehicle_count > 0 else 0
            throughput = traci.simulation.getArrivedNumber()

            writer.writerow([step, vehicle_count, avg_speed, throughput])

            print(f"Step {step} | Vehicles: {vehicle_count} | AvgSpeed: {avg_speed:.2f}")

            step += 1

        f.close()
        print("Simulation ended. CSV saved.")

    except Exception as e:
        print("Simulation error:", e)

    finally:
        traci.close()

    # CALL GRAPH FUNCTION (VERY IMPORTANT)
    plot_graph()

# -----------------------------
# MAIN ENTRY
# -----------------------------
if __name__ == "__main__":
    run()