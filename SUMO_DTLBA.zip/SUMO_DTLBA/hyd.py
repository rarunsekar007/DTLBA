import os
import sys
import csv
import math
from pathlib import Path
from typing import Dict, List, Tuple

import traci


# ============================================================
# User settings
# ============================================================
SUMO_GUI = True
NET_FILE = "hyd.net.xml"
ROUTE_FILE = "routes.rou.xml"
OUTPUT_CSV = "simulation_log.csv"
STEP_LIMIT = 1000

# DTLBA symbolic/estimated timing values in ms
T_PM = 208.4999
T_PA = 0.088692
T_RND = 0.067234
T_SM = 0.026891
T_SPL = 0.075322
T_CHA = 0.311136
T_MOD2 = 0.604391
T_H = 0.073671
T_SYM = 0.046492
T_FE = 0.020266
T_XOR = 0.065804

# Thresholds for mobility-aware logic
PREDICTIVE_DISTANCE_THRESHOLD = 120.0   # meters
HANDOVER_DISTANCE_THRESHOLD = 50.0      # meters
BATCH_GROUP_SIZE = 5

# ============================================================
# Helpers
# ============================================================


def get_sumo_binary(use_gui: bool) -> str:
    sumo_home = os.environ.get("SUMO_HOME")
    if not sumo_home:
        raise EnvironmentError(
            "SUMO_HOME is not set. Please set SUMO_HOME before running main.py."
        )
    tools = os.path.join(sumo_home, "tools")
    if tools not in sys.path:
        sys.path.append(tools)

    binary = "sumo-gui" if use_gui else "sumo"
    return binary


def ensure_files_exist(base_dir: Path) -> None:
    required = [NET_FILE, ROUTE_FILE]
    missing = [f for f in required if not (base_dir / f).exists()]
    if missing:
        raise FileNotFoundError(
            f"Missing required SUMO files: {missing}. "
            f"Make sure {NET_FILE} and {ROUTE_FILE} are present."
        )


def average(values: List[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def estimate_normal_auth_cost_ms() -> float:
    # Based on your proposed normal verification pattern:
    # 2(Tpm + Trnd) + Th + 3Tpa
    return 2 * (T_PM + T_RND) + T_H + 3 * T_PA


def estimate_predictive_auth_cost_ms() -> float:
    # Lightweight predictive verification:
    # Th + comparison ~ modeled by Tpa
    return T_H + T_PA


def estimate_handover_auth_cost_ms() -> float:
    # Approximation:
    # (Tpm + Trnd) + Th + 2Tpa
    return (T_PM + T_RND) + T_H + 2 * T_PA


def estimate_batch_auth_cost_ms(batch_size: int) -> float:
    # Approximation from your batch expression:
    # N(Th + 4Tpa) + 2(Tpm + Trnd) + 3Tpa
    return batch_size * (T_H + 4 * T_PA) + 2 * (T_PM + T_RND) + 3 * T_PA


def get_vehicle_rsu_zone(x: float) -> int:
    # Simple spatial partition for RSU regions across the road
    # You can refine these boundaries based on your map scale.
    if x < 300:
        return 1
    if x < 700:
        return 2
    return 3


def compute_density(vehicle_count: int, lane_length_sum_m: float) -> float:
    # vehicles per km
    if lane_length_sum_m <= 0:
        return 0.0
    return vehicle_count / (lane_length_sum_m / 1000.0)


def get_total_lane_length() -> float:
    total = 0.0
    for lane_id in traci.lane.getIDList():
        try:
            total += traci.lane.getLength(lane_id)
        except traci.TraCIException:
            continue
    return total


# ============================================================
# DTLBA-like lightweight state tracking
# ============================================================

class VehicleState:
    def __init__(self, veh_id: str) -> None:
        self.veh_id = veh_id
        self.last_zone: int | None = None
        self.predicted_next_zone: int | None = None
        self.did_normal_auth = False
        self.did_predictive_auth = False
        self.last_seen_step = -1


def predict_next_zone(position_x: float, speed: float, current_zone: int) -> int:
    # Simple mobility-aware prediction
    if speed > 5.0:
        if current_zone == 1 and position_x > 220:
            return 2
        if current_zone == 2 and position_x > 620:
            return 3
    return current_zone


# ============================================================
# Main simulation
# ============================================================

def run_simulation() -> None:
    base_dir = Path.cwd()
    ensure_files_exist(base_dir)

    sumo_binary = get_sumo_binary(SUMO_GUI)

    sumo_cmd = [
        sumo_binary,
        "-n", str(base_dir / NET_FILE),
        "-r", str(base_dir / ROUTE_FILE),
        "--start",
        "--quit-on-end",
        "--step-length", "1.0",
    ]

    traci.start(sumo_cmd)

    lane_length_sum = get_total_lane_length()
    vehicle_states: Dict[str, VehicleState] = {}

    rows: List[Dict[str, float | int]] = []

    total_auth_cost_ms = 0.0

    try:
        for step in range(STEP_LIMIT):
            traci.simulationStep()

            veh_ids = traci.vehicle.getIDList()
            speeds: List[float] = []
            arrived_this_step = traci.simulation.getArrivedNumber()
            departed_this_step = traci.simulation.getDepartedNumber()

            normal_auth_count = 0
            predictive_auth_count = 0
            handover_auth_count = 0
            batch_auth_count = 0
            batch_auth_cost_ms = 0.0

            # Per-vehicle processing
            for veh_id in veh_ids:
                speed = traci.vehicle.getSpeed(veh_id)
                x, y = traci.vehicle.getPosition(veh_id)
                speeds.append(speed)

                if veh_id not in vehicle_states:
                    vehicle_states[veh_id] = VehicleState(veh_id)

                state = vehicle_states[veh_id]
                state.last_seen_step = step

                current_zone = get_vehicle_rsu_zone(x)

                # Initial authentication
                if not state.did_normal_auth:
                    state.did_normal_auth = True
                    state.last_zone = current_zone
                    normal_auth_count += 1
                    total_auth_cost_ms += estimate_normal_auth_cost_ms()

                # Predictive authentication
                predicted_zone = predict_next_zone(x, speed, current_zone)
                if (
                    predicted_zone != current_zone
                    and not state.did_predictive_auth
                ):
                    state.predicted_next_zone = predicted_zone
                    state.did_predictive_auth = True
                    predictive_auth_count += 1
                    total_auth_cost_ms += estimate_predictive_auth_cost_ms()

                # Handover authentication
                if state.last_zone is not None and current_zone != state.last_zone:
                    handover_auth_count += 1
                    total_auth_cost_ms += estimate_handover_auth_cost_ms()
                    state.last_zone = current_zone
                    state.did_predictive_auth = False
                    state.predicted_next_zone = None

            # Batch authentication at RSU side
            if len(veh_ids) >= BATCH_GROUP_SIZE:
                full_batches = len(veh_ids) // BATCH_GROUP_SIZE
                for _ in range(full_batches):
                    batch_auth_count += 1
                    batch_auth_cost_ms += estimate_batch_auth_cost_ms(BATCH_GROUP_SIZE)
                total_auth_cost_ms += batch_auth_cost_ms

            avg_speed = average(speeds)
            density = compute_density(len(veh_ids), lane_length_sum)
            throughput = arrived_this_step

            rows.append({
                "step": step,
                "active_vehicles": len(veh_ids),
                "departed": departed_this_step,
                "arrived": arrived_this_step,
                "throughput": throughput,
                "average_speed_mps": round(avg_speed, 4),
                "average_speed_kmph": round(avg_speed * 3.6, 4),
                "density_veh_per_km": round(density, 4),
                "normal_auth_count": normal_auth_count,
                "predictive_auth_count": predictive_auth_count,
                "handover_auth_count": handover_auth_count,
                "batch_auth_count": batch_auth_count,
                "batch_auth_cost_ms": round(batch_auth_cost_ms, 4),
                "cumulative_auth_cost_ms": round(total_auth_cost_ms, 4),
            })

    finally:
        traci.close()

    with open(base_dir / OUTPUT_CSV, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "step",
                "active_vehicles",
                "departed",
                "arrived",
                "throughput",
                "average_speed_mps",
                "average_speed_kmph",
                "density_veh_per_km",
                "normal_auth_count",
                "predictive_auth_count",
                "handover_auth_count",
                "batch_auth_count",
                "batch_auth_cost_ms",
                "cumulative_auth_cost_ms",
            ],
        )
        writer.writeheader()
        writer.writerows(rows)

    print(f"Simulation completed successfully.")
    print(f"Output file generated: {base_dir / OUTPUT_CSV}")


if __name__ == "__main__":
    run_simulation()