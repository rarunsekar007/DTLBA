"""Analyze DTLBA SUMO DT-prediction outputs and generate reviewer-ready results.

Run after DTLBA_dt_prediction_mobility.py:
    python DTLBA_dt_prediction_results.py

Outputs:
    dt_prediction_summary.csv
    dt_accuracy_by_speed.csv
    dt_accuracy_by_density.csv
    fig_dt_accuracy_speed.png
    fig_dt_accuracy_density.png
    fig_dt_handover_delay.png
    fig_dt_inference_density.png
"""

from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

BASE = Path(__file__).resolve().parent
EVENT_CSV = BASE / "dt_prediction_events.csv"

if not EVENT_CSV.exists():
    raise FileNotFoundError(
        f"{EVENT_CSV.name} was not found. Run DTLBA_dt_prediction_mobility.py first."
    )

df = pd.read_csv(EVENT_CSV)
if df.empty:
    raise RuntimeError(
        "No resolved next-RSU predictions were recorded. Increase STEP_LIMIT/RSU_RANGE_M or "
        "adjust NUM_RSUS and PREDICTION_TRIGGER_FRACTION, then rerun the SUMO experiment."
    )

# -----------------------------------------------------------------------------
# Overall reproducible summary
# -----------------------------------------------------------------------------
summary = pd.DataFrame([{
    "resolved_predictions": len(df),
    "correct_predictions": int(df["correct"].sum()),
    "top1_accuracy_pct": 100.0 * df["correct"].mean(),
    "false_prefetch_rate_pct": 100.0 * df["false_prefetch"].mean(),
    "mean_inference_ms": df["inference_ms"].mean(),
    "std_inference_ms": df["inference_ms"].std(ddof=1) if len(df) > 1 else 0.0,
    "mean_prediction_lead_time_s": df["lead_time_s"].mean(),
    "mean_baseline_handover_ms": df["baseline_no_dt_handover_ms"].mean(),
    "mean_dt_handover_ms": df["dt_handover_ms"].mean(),
    "mean_delay_reduction_pct": df["delay_reduction_pct"].mean(),
}])
summary.to_csv(BASE / "dt_prediction_summary.csv", index=False)

# -----------------------------------------------------------------------------
# Speed analysis
# -----------------------------------------------------------------------------
speed_order = ["low_<40", "medium_40-60", "high_>=60"]
speed_stats = (
    df.groupby("speed_class", observed=True)
      .agg(events=("correct", "size"), accuracy_pct=("correct", lambda x: 100*x.mean()),
           false_prefetch_pct=("false_prefetch", lambda x: 100*x.mean()),
           mean_inference_ms=("inference_ms", "mean"), mean_handover_ms=("dt_handover_ms", "mean"))
      .reindex(speed_order)
      .dropna(how="all")
      .reset_index()
)
speed_stats.to_csv(BASE / "dt_accuracy_by_speed.csv", index=False)

plt.figure(figsize=(7.2, 4.8))
plt.bar(speed_stats["speed_class"], speed_stats["accuracy_pct"])
plt.xlabel("Vehicle speed class, km/h")
plt.ylabel("Next-RSU prediction accuracy, %")
plt.ylim(0, 100)
plt.tight_layout()
plt.savefig(BASE / "fig_dt_accuracy_speed.png", dpi=600, bbox_inches="tight")
plt.close()

# -----------------------------------------------------------------------------
# Density/load analysis: use active vehicle count at actual handover.
# Quantile bins adapt to the user's real SUMO traffic rather than inventing loads.
# -----------------------------------------------------------------------------
unique_loads = df["active_vehicles_at_handover"].nunique()
q = min(4, unique_loads)
if q >= 2:
    df["density_bin"] = pd.qcut(df["active_vehicles_at_handover"], q=q, duplicates="drop")
    density_stats = (
        df.groupby("density_bin", observed=True)
          .agg(events=("correct", "size"),
               mean_active_vehicles=("active_vehicles_at_handover", "mean"),
               accuracy_pct=("correct", lambda x: 100*x.mean()),
               false_prefetch_pct=("false_prefetch", lambda x: 100*x.mean()),
               mean_inference_ms=("inference_ms", "mean"))
          .reset_index()
    )
    density_stats["density_bin"] = density_stats["density_bin"].astype(str)
else:
    density_stats = pd.DataFrame([{
        "density_bin": "all",
        "events": len(df),
        "mean_active_vehicles": df["active_vehicles_at_handover"].mean(),
        "accuracy_pct": 100*df["correct"].mean(),
        "false_prefetch_pct": 100*df["false_prefetch"].mean(),
        "mean_inference_ms": df["inference_ms"].mean(),
    }])

density_stats.to_csv(BASE / "dt_accuracy_by_density.csv", index=False)

plt.figure(figsize=(7.2, 4.8))
plt.plot(density_stats["mean_active_vehicles"], density_stats["accuracy_pct"], marker="o")
plt.xlabel("Active vehicles at handover")
plt.ylabel("Next-RSU prediction accuracy, %")
plt.ylim(0, 100)
plt.tight_layout()
plt.savefig(BASE / "fig_dt_accuracy_density.png", dpi=600, bbox_inches="tight")
plt.close()

plt.figure(figsize=(7.2, 4.8))
plt.plot(density_stats["mean_active_vehicles"], density_stats["mean_inference_ms"], marker="o")
plt.xlabel("Active vehicles at handover")
plt.ylabel("DT prediction time, ms")
plt.tight_layout()
plt.savefig(BASE / "fig_dt_inference_density.png", dpi=600, bbox_inches="tight")
plt.close()

# -----------------------------------------------------------------------------
# Correct-vs-wrong prediction impact on handover delay
# -----------------------------------------------------------------------------
labels = ["Without DT"]
values = [df["baseline_no_dt_handover_ms"].mean()]
correct_df = df[df["correct"] == 1]
wrong_df = df[df["correct"] == 0]
if not correct_df.empty:
    labels.append("DTLBA: correct")
    values.append(correct_df["dt_handover_ms"].mean())
if not wrong_df.empty:
    labels.append("DTLBA: incorrect")
    values.append(wrong_df["dt_handover_ms"].mean())

plt.figure(figsize=(7.2, 4.8))
plt.bar(labels, values)
plt.ylabel("Handover authentication delay, ms")
plt.xticks(rotation=10)
plt.tight_layout()
plt.savefig(BASE / "fig_dt_handover_delay.png", dpi=600, bbox_inches="tight")
plt.close()

print("\nDT Prediction and Mobility Analysis Summary")
print(summary.round(4).to_string(index=False))
print("\nGenerated files:")
for name in [
    "dt_prediction_summary.csv", "dt_accuracy_by_speed.csv", "dt_accuracy_by_density.csv",
    "fig_dt_accuracy_speed.png", "fig_dt_accuracy_density.png",
    "fig_dt_handover_delay.png", "fig_dt_inference_density.png",
]:
    print(" -", BASE / name)
