import csv
from pathlib import Path

import matplotlib.pyplot as plt


INPUT_CSV = "simulation_log.csv"


def read_log(csv_path: Path):
    steps = []
    avg_speed_kmph = []
    density = []
    throughput = []
    cumulative_auth_cost = []

    with open(csv_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            steps.append(int(row["step"]))
            avg_speed_kmph.append(float(row["average_speed_kmph"]))
            density.append(float(row["density_veh_per_km"]))
            throughput.append(float(row["throughput"]))
            cumulative_auth_cost.append(float(row["cumulative_auth_cost_ms"]))

    return steps, avg_speed_kmph, density, throughput, cumulative_auth_cost


def plot_single(x, y, xlabel, ylabel, title, output_file):
    plt.figure(figsize=(8, 5))
    plt.plot(x, y, marker="o", linewidth=1.5, markersize=3)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.title(title)
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(output_file, dpi=300)
    plt.close()


def main():
    base_dir = Path.cwd()
    csv_path = base_dir / INPUT_CSV

    if not csv_path.exists():
        raise FileNotFoundError(
            f"{INPUT_CSV} not found in {base_dir}. Run main.py first."
        )

    steps, avg_speed_kmph, density, throughput, cumulative_auth_cost = read_log(csv_path)

    plot_single(
        steps,
        avg_speed_kmph,
        xlabel="Simulation Step",
        ylabel="Average Speed (km/h)",
        title="Speed vs Time",
        output_file=base_dir / "speed_vs_time.png",
    )

    plot_single(
        steps,
        density,
        xlabel="Simulation Step",
        ylabel="Density (vehicles/km)",
        title="Vehicle Density vs Time",
        output_file=base_dir / "density_vs_time.png",
    )

    plot_single(
        steps,
        throughput,
        xlabel="Simulation Step",
        ylabel="Throughput (vehicles arrived per step)",
        title="Throughput vs Time",
        output_file=base_dir / "throughput_vs_time.png",
    )

    plot_single(
        steps,
        cumulative_auth_cost,
        xlabel="Simulation Step",
        ylabel="Cumulative Authentication Cost (ms)",
        title="Authentication Cost vs Time",
        output_file=base_dir / "auth_cost_vs_time.png",
    )

    print("Plots generated successfully:")
    print(" - speed_vs_time.png")
    print(" - density_vs_time.png")
    print(" - throughput_vs_time.png")
    print(" - auth_cost_vs_time.png")


if __name__ == "__main__":
    main()