"""DTLBA Digital-Twin Prediction and Mobility Analysis (v2).

Purpose
-------
Use SUMO/TraCI as mobility ground truth and evaluate next-RSU prediction.
This revision fixes the earlier accumulation of unresolved predictions by:
  1) assigning every vehicle to its nearest RSU (Voronoi serving regions),
  2) keeping at most one active prediction per vehicle,
  3) creating a prediction only when the future position indicates a likely
     transition to a different RSU,
  4) resolving a prediction on the next actual RSU transition, and
  5) explicitly recording expired / vehicle-left predictions.

Place beside hyd.net.xml and routes.rou.xml and run:
    python DTLBA_dt_prediction_mobility_v2.py

Outputs
-------
  dt_prediction_events_v2.csv : every prediction (correct/wrong/expired/vehicle_left)
  dt_handover_events_v2.csv   : every observed RSU transition
  dt_step_metrics_v2.csv      : per-step mobility/load statistics
  dt_rsu_locations_v2.csv     : selected RSU coordinates
  dt_summary_v2.csv           : overall DT prediction metrics

Important
---------
Prediction accuracy is computed only from resolved predictions. Resolution
rate is reported separately so that accuracy cannot hide unresolved events.
The script does NOT fabricate authentication latency or cryptographic timings.
"""

import csv
import math
import os
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# --------------------------- USER CONFIGURATION -----------------------------
SUMO_GUI = False
NET_FILE = "hyd.net.xml"
ROUTE_FILE = "routes.rou.xml"
STEP_LENGTH_S = 1.0
STEP_LIMIT = 3600
RANDOM_SEED = 42

NUM_RSUS = 8
# Future-position horizon. 8--15 s is a useful starting range for handover
# pre-authentication. Keep the selected value fixed when reporting results.
PREDICTION_HORIZON_S = 10.0
# Do not repeatedly predict at every SUMO step.
PREDICTION_COOLDOWN_S = 5.0
# A prediction that does not encounter an RSU transition in this time expires.
PREDICTION_TIMEOUT_S = 60.0
# Ignore nearly stationary vehicles.
MIN_PREDICTION_SPEED_MPS = 1.0
# Require the predicted future point to be this much closer to the candidate
# RSU than to the current RSU. This suppresses noisy boundary predictions.
MIN_FUTURE_DISTANCE_GAIN_M = 5.0

EVENT_CSV = "dt_prediction_events_v2.csv"
HANDOVER_CSV = "dt_handover_events_v2.csv"
STEP_CSV = "dt_step_metrics_v2.csv"
RSU_CSV = "dt_rsu_locations_v2.csv"
SUMMARY_CSV = "dt_summary_v2.csv"

# ------------------------------- SUMO SETUP ---------------------------------
SUMO_HOME = os.environ.get("SUMO_HOME")
if not SUMO_HOME:
    raise EnvironmentError(
        "SUMO_HOME is not set. Example on Windows: set SUMO_HOME=C:\\Program Files (x86)\\Eclipse\\Sumo"
    )
SUMO_TOOLS = os.path.join(SUMO_HOME, "tools")
if SUMO_TOOLS not in sys.path:
    sys.path.append(SUMO_TOOLS)

try:
    import traci  # type: ignore
except ImportError as exc:
    raise ImportError(
        "Could not import TraCI. Verify SUMO_HOME and that SUMO's tools folder exists."
    ) from exc


@dataclass
class Prediction:
    vehicle: str
    prediction_step: int
    prediction_time_s: float
    current_rsu: str
    predicted_rsu: str
    x_m: float
    y_m: float
    speed_mps: float
    angle_deg: float
    future_x_m: float
    future_y_m: float
    inference_ms: float
    active_vehicles: int


@dataclass
class VehicleState:
    current_rsu: Optional[str] = None
    pending: Optional[Prediction] = None
    last_prediction_time_s: float = -1.0e30
    handover_count: int = 0


def distance(a: Tuple[float, float], b: Tuple[float, float]) -> float:
    return math.hypot(a[0] - b[0], a[1] - b[1])


def get_candidate_junctions() -> List[Tuple[str, float, float]]:
    candidates: List[Tuple[str, float, float]] = []
    for jid in traci.junction.getIDList():
        if jid.startswith(":"):
            continue
        try:
            x, y = traci.junction.getPosition(jid)
            if math.isfinite(x) and math.isfinite(y):
                candidates.append((jid, float(x), float(y)))
        except traci.TraCIException:
            continue
    if not candidates:
        raise RuntimeError("No usable non-internal junctions were found in hyd.net.xml.")
    return candidates


def choose_rsus(candidates: List[Tuple[str, float, float]], k: int) -> Dict[str, Tuple[float, float]]:
    """Spread RSUs over the road network with deterministic farthest-point sampling."""
    k = max(2, min(int(k), len(candidates)))
    cx = sum(c[1] for c in candidates) / len(candidates)
    cy = sum(c[2] for c in candidates) / len(candidates)
    first = min(candidates, key=lambda c: (c[1] - cx) ** 2 + (c[2] - cy) ** 2)
    selected = [first]
    remaining = [c for c in candidates if c[0] != first[0]]
    while len(selected) < k and remaining:
        nxt = max(
            remaining,
            key=lambda c: min(distance((c[1], c[2]), (s[1], s[2])) for s in selected),
        )
        selected.append(nxt)
        remaining = [c for c in remaining if c[0] != nxt[0]]
    return {f"RSU{i+1}": (c[1], c[2]) for i, c in enumerate(selected)}


def nearest_rsu(x: float, y: float, rsus: Dict[str, Tuple[float, float]]) -> Tuple[str, float]:
    rid, pos = min(rsus.items(), key=lambda item: distance((x, y), item[1]))
    return rid, distance((x, y), pos)


def future_position(x: float, y: float, speed_mps: float, angle_deg: float) -> Tuple[float, float]:
    # SUMO convention: 0 deg = north, 90 deg = east.
    theta = math.radians(angle_deg)
    d = max(0.0, speed_mps) * PREDICTION_HORIZON_S
    return x + d * math.sin(theta), y + d * math.cos(theta)


def predict_next_rsu(
    x: float,
    y: float,
    speed_mps: float,
    angle_deg: float,
    current_rsu: str,
    rsus: Dict[str, Tuple[float, float]],
) -> Tuple[Optional[str], float, float]:
    """Predict a different RSU only when the extrapolated future point supports it."""
    fx, fy = future_position(x, y, speed_mps, angle_deg)
    future_rsu, future_candidate_dist = nearest_rsu(fx, fy, rsus)
    if future_rsu == current_rsu:
        return None, fx, fy
    future_current_dist = distance((fx, fy), rsus[current_rsu])
    gain = future_current_dist - future_candidate_dist
    if gain < MIN_FUTURE_DISTANCE_GAIN_M:
        return None, fx, fy
    return future_rsu, fx, fy


def speed_class(speed_mps: float) -> str:
    kmph = speed_mps * 3.6
    if kmph < 40.0:
        return "low_<40"
    if kmph < 60.0:
        return "medium_40-60"
    return "high_>=60"


def prediction_row(p: Prediction, status: str, actual_next_rsu: str = "", now_s: float = 0.0,
                   handover_step: str = "") -> dict:
    resolved = status in ("correct", "wrong")
    correct = 1 if status == "correct" else (0 if status == "wrong" else "")
    false_prefetch = 0 if status == "correct" else (1 if status == "wrong" else "")
    lead = (now_s - p.prediction_time_s) if resolved else ""
    return {
        "vehicle": p.vehicle,
        "prediction_step": p.prediction_step,
        "handover_step": handover_step,
        "prediction_time_s": round(p.prediction_time_s, 3),
        "resolution_time_s": round(now_s, 3),
        "lead_time_s": round(lead, 3) if resolved else "",
        "current_rsu": p.current_rsu,
        "predicted_rsu": p.predicted_rsu,
        "actual_next_rsu": actual_next_rsu,
        "status": status,
        "resolved": 1 if resolved else 0,
        "correct": correct,
        "false_prefetch": false_prefetch,
        "speed_mps": round(p.speed_mps, 4),
        "speed_kmph": round(p.speed_mps * 3.6, 4),
        "speed_class": speed_class(p.speed_mps),
        "angle_deg": round(p.angle_deg, 3),
        "x_m": round(p.x_m, 3),
        "y_m": round(p.y_m, 3),
        "future_x_m": round(p.future_x_m, 3),
        "future_y_m": round(p.future_y_m, 3),
        "inference_ms": round(p.inference_ms, 6),
        "active_vehicles_at_prediction": p.active_vehicles,
    }


def write_csv(path: Path, rows: List[dict], fields: List[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def run() -> None:
    base = Path(__file__).resolve().parent
    for filename in (NET_FILE, ROUTE_FILE):
        if not (base / filename).is_file():
            raise FileNotFoundError(f"Required SUMO file not found: {base / filename}")

    binary_name = "sumo-gui" if SUMO_GUI else "sumo"
    try:
        from sumolib import checkBinary  # type: ignore
        sumo_binary = checkBinary(binary_name)
    except Exception:
        sumo_binary = binary_name

    command = [
        sumo_binary,
        "-n", str(base / NET_FILE),
        "-r", str(base / ROUTE_FILE),
        "--step-length", str(STEP_LENGTH_S),
        "--seed", str(RANDOM_SEED),
        "--no-step-log", "true",
        "--no-warnings", "true",
        "--quit-on-end", "true",
    ]

    states: Dict[str, VehicleState] = {}
    event_rows: List[dict] = []
    handover_rows: List[dict] = []
    step_rows: List[dict] = []
    rsus: Dict[str, Tuple[float, float]] = {}

    traci.start(command)
    try:
        rsus = choose_rsus(get_candidate_junctions(), NUM_RSUS)
        with (base / RSU_CSV).open("w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["rsu_id", "x_m", "y_m", "assignment"])
            for rid, (rx, ry) in rsus.items():
                w.writerow([rid, round(rx, 3), round(ry, 3), "nearest-RSU Voronoi region"])

        previous_ids = set()
        for step in range(STEP_LIMIT):
            if traci.simulation.getMinExpectedNumber() <= 0:
                break
            traci.simulationStep()
            now_s = float(traci.simulation.getTime())
            ids = set(traci.vehicle.getIDList())
            active_count = len(ids)
            speeds: List[float] = []
            resolved_step = 0
            correct_step = 0
            wrong_step = 0
            expired_step = 0

            # Vehicles that left SUMO: explicitly close any active prediction.
            for vid in previous_ids - ids:
                state = states.get(vid)
                if state and state.pending is not None:
                    event_rows.append(prediction_row(state.pending, "vehicle_left", now_s=now_s))
                    state.pending = None
            previous_ids = ids.copy()

            for vid in ids:
                try:
                    x, y = map(float, traci.vehicle.getPosition(vid))
                    speed = float(traci.vehicle.getSpeed(vid))
                    angle = float(traci.vehicle.getAngle(vid))
                except (traci.TraCIException, TypeError, ValueError):
                    continue

                speeds.append(speed)
                actual_rsu, actual_dist = nearest_rsu(x, y, rsus)
                state = states.setdefault(vid, VehicleState())

                if state.current_rsu is None:
                    state.current_rsu = actual_rsu

                # Ground-truth handover = nearest serving RSU changed.
                if actual_rsu != state.current_rsu:
                    old_rsu = state.current_rsu
                    state.handover_count += 1
                    handover_rows.append({
                        "vehicle": vid,
                        "step": step,
                        "time_s": round(now_s, 3),
                        "from_rsu": old_rsu,
                        "to_rsu": actual_rsu,
                        "x_m": round(x, 3),
                        "y_m": round(y, 3),
                        "speed_kmph": round(speed * 3.6, 4),
                        "active_vehicles": active_count,
                        "had_pending_prediction": 1 if state.pending is not None else 0,
                    })

                    if state.pending is not None:
                        p = state.pending
                        status = "correct" if p.predicted_rsu == actual_rsu else "wrong"
                        event_rows.append(prediction_row(
                            p, status, actual_next_rsu=actual_rsu,
                            now_s=now_s, handover_step=str(step)
                        ))
                        resolved_step += 1
                        if status == "correct":
                            correct_step += 1
                        else:
                            wrong_step += 1
                        state.pending = None
                    state.current_rsu = actual_rsu

                # Explicit timeout: unresolved is NOT counted as wrong accuracy.
                if state.pending is not None:
                    age = now_s - state.pending.prediction_time_s
                    if age >= PREDICTION_TIMEOUT_S:
                        event_rows.append(prediction_row(state.pending, "expired", now_s=now_s))
                        state.pending = None
                        expired_step += 1

                # At most one prediction per vehicle. A new prediction is made
                # only if extrapolated future location belongs to another RSU.
                if (
                    state.pending is None
                    and speed >= MIN_PREDICTION_SPEED_MPS
                    and now_s - state.last_prediction_time_s >= PREDICTION_COOLDOWN_S
                ):
                    t0 = time.perf_counter_ns()
                    predicted, fx, fy = predict_next_rsu(
                        x, y, speed, angle, state.current_rsu, rsus
                    )
                    inference_ms = (time.perf_counter_ns() - t0) / 1_000_000.0
                    if predicted is not None:
                        state.pending = Prediction(
                            vehicle=vid,
                            prediction_step=step,
                            prediction_time_s=now_s,
                            current_rsu=state.current_rsu,
                            predicted_rsu=predicted,
                            x_m=x,
                            y_m=y,
                            speed_mps=speed,
                            angle_deg=angle,
                            future_x_m=fx,
                            future_y_m=fy,
                            inference_ms=inference_ms,
                            active_vehicles=active_count,
                        )
                        state.last_prediction_time_s = now_s

            avg_speed = sum(speeds) / len(speeds) if speeds else 0.0
            step_rows.append({
                "step": step,
                "simulation_time_s": round(now_s, 3),
                "active_vehicles": active_count,
                "departed": traci.simulation.getDepartedNumber(),
                "arrived": traci.simulation.getArrivedNumber(),
                "average_speed_mps": round(avg_speed, 4),
                "average_speed_kmph": round(avg_speed * 3.6, 4),
                "pending_predictions": sum(1 for s in states.values() if s.pending is not None),
                "resolved_predictions": resolved_step,
                "correct_predictions": correct_step,
                "wrong_predictions": wrong_step,
                "expired_predictions": expired_step,
                "cumulative_handovers": len(handover_rows),
            })

        # Close predictions still active at simulation end.
        final_time = float(traci.simulation.getTime())
        for state in states.values():
            if state.pending is not None:
                event_rows.append(prediction_row(state.pending, "simulation_end", now_s=final_time))
                state.pending = None

    finally:
        try:
            traci.close()
        except Exception:
            pass

    event_fields = [
        "vehicle", "prediction_step", "handover_step", "prediction_time_s",
        "resolution_time_s", "lead_time_s", "current_rsu", "predicted_rsu",
        "actual_next_rsu", "status", "resolved", "correct", "false_prefetch",
        "speed_mps", "speed_kmph", "speed_class", "angle_deg", "x_m", "y_m",
        "future_x_m", "future_y_m", "inference_ms", "active_vehicles_at_prediction",
    ]
    handover_fields = [
        "vehicle", "step", "time_s", "from_rsu", "to_rsu", "x_m", "y_m",
        "speed_kmph", "active_vehicles", "had_pending_prediction",
    ]
    step_fields = [
        "step", "simulation_time_s", "active_vehicles", "departed", "arrived",
        "average_speed_mps", "average_speed_kmph", "pending_predictions",
        "resolved_predictions", "correct_predictions", "wrong_predictions",
        "expired_predictions", "cumulative_handovers",
    ]
    write_csv(base / EVENT_CSV, event_rows, event_fields)
    write_csv(base / HANDOVER_CSV, handover_rows, handover_fields)
    write_csv(base / STEP_CSV, step_rows, step_fields)

    resolved = [r for r in event_rows if r["status"] in ("correct", "wrong")]
    correct = sum(1 for r in resolved if r["status"] == "correct")
    wrong = sum(1 for r in resolved if r["status"] == "wrong")
    total_predictions = len(event_rows)
    expired = sum(1 for r in event_rows if r["status"] == "expired")
    vehicle_left = sum(1 for r in event_rows if r["status"] == "vehicle_left")
    sim_end = sum(1 for r in event_rows if r["status"] == "simulation_end")
    resolution_rate = 100.0 * len(resolved) / total_predictions if total_predictions else 0.0
    accuracy = 100.0 * correct / len(resolved) if resolved else 0.0
    false_prefetch = 100.0 * wrong / len(resolved) if resolved else 0.0
    mean_infer = (
        sum(float(r["inference_ms"]) for r in event_rows) / total_predictions
        if total_predictions else 0.0
    )
    mean_lead = (
        sum(float(r["lead_time_s"]) for r in resolved) / len(resolved)
        if resolved else 0.0
    )
    predicted_handovers = sum(int(r["had_pending_prediction"]) for r in handover_rows)
    handover_prediction_coverage = (
        100.0 * predicted_handovers / len(handover_rows) if handover_rows else 0.0
    )

    summary_rows = [
        {"metric": "Total predictions", "value": total_predictions, "unit": "count"},
        {"metric": "Resolved predictions", "value": len(resolved), "unit": "count"},
        {"metric": "Correct predictions", "value": correct, "unit": "count"},
        {"metric": "Wrong predictions", "value": wrong, "unit": "count"},
        {"metric": "Expired predictions", "value": expired, "unit": "count"},
        {"metric": "Vehicle-left predictions", "value": vehicle_left, "unit": "count"},
        {"metric": "Simulation-end predictions", "value": sim_end, "unit": "count"},
        {"metric": "Prediction resolution rate", "value": round(resolution_rate, 4), "unit": "%"},
        {"metric": "Top-1 next-RSU accuracy", "value": round(accuracy, 4), "unit": "%"},
        {"metric": "False-prefetch rate", "value": round(false_prefetch, 4), "unit": "%"},
        {"metric": "Observed RSU handovers", "value": len(handover_rows), "unit": "count"},
        {"metric": "Handovers with prior prediction", "value": predicted_handovers, "unit": "count"},
        {"metric": "Handover prediction coverage", "value": round(handover_prediction_coverage, 4), "unit": "%"},
        {"metric": "Mean inference time", "value": round(mean_infer, 6), "unit": "ms"},
        {"metric": "Mean prediction lead time", "value": round(mean_lead, 4), "unit": "s"},
    ]
    write_csv(base / SUMMARY_CSV, summary_rows, ["metric", "value", "unit"])

    print("\nDTLBA DT Prediction and Mobility Analysis v2 completed")
    print("------------------------------------------------------")
    print(f"Observed RSU handovers          : {len(handover_rows)}")
    print(f"Total predictions               : {total_predictions}")
    print(f"Resolved predictions            : {len(resolved)}")
    print(f"Prediction resolution rate      : {resolution_rate:.2f}%")
    print(f"Top-1 next-RSU accuracy         : {accuracy:.2f}%")
    print(f"False-prefetch rate             : {false_prefetch:.2f}%")
    print(f"Handover prediction coverage    : {handover_prediction_coverage:.2f}%")
    print(f"Mean inference time             : {mean_infer:.6f} ms")
    print(f"Mean prediction lead time       : {mean_lead:.3f} s")
    print(f"\nOutput folder: {base}")
    print(f"  {EVENT_CSV}")
    print(f"  {HANDOVER_CSV}")
    print(f"  {STEP_CSV}")
    print(f"  {RSU_CSV}")
    print(f"  {SUMMARY_CSV}")


if __name__ == "__main__":
    run()
