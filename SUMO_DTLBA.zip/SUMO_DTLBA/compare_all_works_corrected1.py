import csv
from pathlib import Path
import matplotlib.pyplot as plt

# ============================================================
# GLOBAL FONT : Times New Roman
# ============================================================
plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["font.size"] = 11

# ============================================================
# INPUT FILE
# ============================================================
SIM_LOG_CSV = "simulation_log.csv"

# ============================================================
# SCHEME DATA
# ============================================================
SCHEMES = {
    "Huang et al.\n(w1)": {
        "comp_vehicle_ms": 627.831584,
        "comp_edge_ms": 627.684242,
        "comm_bytes": 3568,
    },
    "Liu et al.\n(w2)": {
        "comp_vehicle_ms": 1253.331133,
        "comp_edge_ms": 1253.331133,
        "comm_bytes": 6336,
    },
    "Yan et al.\n(w3)": {
        "comp_vehicle_ms": 417.604189,
        "comp_edge_ms": 1668.824602,
        "comm_bytes": 4672,
    },
    "Ahmed et al.\n(w4)": {
        "comp_vehicle_ms": 2506.893294,
        "comp_edge_ms": 2297.272588,
        "comm_bytes": 4736,
    },
    "Proposed\n(w5)": {
        "comp_vehicle_ms": 417.443973,
        "comp_edge_ms": 417.474015,
        "comm_bytes": 4352,
    },
}

# ============================================================
# FIXED COLORS
# ============================================================
SCHEME_COLORS = [
    "royalblue",
    "darkorange",
    "seagreen",
    "crimson",
    "mediumpurple",
]

# ============================================================
# SYSTEM PARAMETERS
# ============================================================
DATA_RATE_BPS = 6_000_000
CPU_POWER_W = 10.88
TX_POWER_W = 10.88


# ============================================================
# HELPERS
# ============================================================
def avg(values):
    return sum(values) / len(values) if values else 0.0


def read_simulation_log():
    path = Path(SIM_LOG_CSV)

    speeds = []
    density = []
    throughput = []

    with open(path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)

        for row in reader:
            if "average_speed_kmph" in row:
                speeds.append(float(row["average_speed_kmph"]))
            elif "speed" in row:
                speeds.append(float(row["speed"]))

            if "density_veh_per_km" in row:
                density.append(float(row["density_veh_per_km"]))
            elif "density" in row:
                density.append(float(row["density"]))

            throughput.append(float(row["throughput"]))

    return avg(speeds), avg(density), avg(throughput)


def communication_delay_ms(comm_bytes):
    return (comm_bytes * 8 / DATA_RATE_BPS) * 1000.0


def total_auth_delay_ms(comp_v, comp_e, comm_bytes):
    return comp_v + comp_e + communication_delay_ms(comm_bytes)


def sumo_delay_ms(auth_delay, density, speed):
    density_factor = 1 + density / 100.0
    speed_factor = 1 + speed / 100.0
    return auth_delay * density_factor / speed_factor


def total_energy_j(comp_v, comp_e, comm_bytes):
    comp = ((comp_v + comp_e) / 1000.0) * CPU_POWER_W
    comm = (comm_bytes * 8 * TX_POWER_W) / DATA_RATE_BPS
    return comp + comm


def throughput_value(base_tp, scheme_delay, min_delay):
    return base_tp * (min_delay / scheme_delay)


# ============================================================
# MAIN GRAPH
# ============================================================
def generate_merged_graph():

    avg_speed, avg_density, avg_tp = read_simulation_log()

    labels = list(SCHEMES.keys())

    auth_delay = []
    sumo_delay = []
    energy = []
    throughput = []

    raw_delay = []

    for label in labels:
        v = SCHEMES[label]

        d = total_auth_delay_ms(
            v["comp_vehicle_ms"],
            v["comp_edge_ms"],
            v["comm_bytes"]
        )
        raw_delay.append(d)

    min_delay = min(raw_delay)

    for label in labels:
        v = SCHEMES[label]

        d = total_auth_delay_ms(
            v["comp_vehicle_ms"],
            v["comp_edge_ms"],
            v["comm_bytes"]
        )

        sd = sumo_delay_ms(d, avg_density, avg_speed)

        en = total_energy_j(
            v["comp_vehicle_ms"],
            v["comp_edge_ms"],
            v["comm_bytes"]
        )

        tp = throughput_value(avg_tp, d, min_delay)

        auth_delay.append(d)
        sumo_delay.append(sd)
        energy.append(en)
        throughput.append(tp)

    # ========================================================
    # 2 x 2 SUBPLOTS
    # ========================================================
    fig, axs = plt.subplots(2, 2, figsize=(14, 10))

    # --------------------------------------------------------
    # Authentication Delay
    # --------------------------------------------------------
    axs[0, 0].bar(labels, auth_delay, color=SCHEME_COLORS, edgecolor="black")
    axs[0, 0].set_title("(a) Authentication Delay", fontweight="bold")
    axs[0, 0].set_ylabel("ms")
    axs[0, 0].tick_params(axis='x', rotation=15)

    # --------------------------------------------------------
    # SUMO Delay
    # --------------------------------------------------------
    axs[0, 1].bar(labels, sumo_delay, color=SCHEME_COLORS, edgecolor="black")
    axs[0, 1].set_title("(b) SUMO Practical Delay", fontweight="bold")
    axs[0, 1].set_ylabel("ms")
    axs[0, 1].tick_params(axis='x', rotation=15)

    # --------------------------------------------------------
    # Energy
    # --------------------------------------------------------
    axs[1, 0].bar(labels, energy, color=SCHEME_COLORS, edgecolor="black")
    axs[1, 0].set_title("(c) Energy Consumption", fontweight="bold")
    axs[1, 0].set_ylabel("J")
    axs[1, 0].tick_params(axis='x', rotation=15)

    # --------------------------------------------------------
    # Throughput
    # --------------------------------------------------------
    axs[1, 1].bar(labels, throughput, color=SCHEME_COLORS, edgecolor="black")
    axs[1, 1].set_title("(d) Throughput Comparison", fontweight="bold")
    axs[1, 1].set_ylabel("Vehicles/step")
    axs[1, 1].tick_params(axis='x', rotation=15)

    # --------------------------------------------------------
    # Grid all
    # --------------------------------------------------------
    for ax in axs.flat:
        ax.grid(axis="y", linestyle="--", alpha=0.5)

    plt.tight_layout()
    plt.savefig("merged_4graphs_comparison.png", dpi=600)
    plt.show()


if __name__ == "__main__":
    generate_merged_graph()