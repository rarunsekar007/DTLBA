"""DTLBA end-to-end density experiment.

Vehicle-density cases: 50, 100, 200, 400, 800 active vehicles.
Integrates:
  (1) SUMO mobility/handover timing when TraCI is available,
  (2) measured DTLBA-v3 MLWR processing routines,
  (3) packet-level discrete-event communication latency (serialization + propagation
      + jitter + FCFS contention + packet loss/retransmission), and
  (4) end-to-end handover/authentication latency and throughput.

IMPORTANT FOR PAPER:
- Processing time is measured by executing the DTLBA v3 reference MLWR routines.
- Mobility is measured from SUMO if --run-sumo is used, or from an existing
  dt_handover_events_v2.csv with --handover-csv.
- Communication latency is SIMULATED at packet level under the explicitly reported
  link parameters below; it is not a physical-radio measurement.
- Do not call this an ns-3/OMNeT++ experiment.

Outputs:
  e2e_density_overall.csv
  e2e_density_repetitions.csv
  e2e_density_communication.csv
  e2e_density_summary.txt
  fig_e2e_latency_vs_density.png
  fig_e2e_throughput_vs_density.png
  fig_e2e_components_vs_density.png
  fig_e2e_packet_loss_vs_density.png
"""
from __future__ import annotations
import argparse, csv, math, os, random, statistics, subprocess, sys, time
from pathlib import Path
from typing import Dict, List
import numpy as np

DENSITIES = [50, 100, 200, 400, 800]
REPETITIONS = 30
SEED = 20260917

# Explicit communication scenario. Change only with a documented reason.
DATA_RATE_MBPS = 10.0
PROPAGATION_MS = 0.05
BASE_MAC_MS = 0.30
JITTER_MS = 0.15
BASE_PACKET_LOSS = 0.005
MAX_PACKET_LOSS = 0.05
MAX_RETRIES = 3
# Authentication arrivals per active vehicle per second used by packet event simulator.
AUTH_EVENT_RATE_PER_VEH_S = 0.02

# Message sizes from the revised v3 DTLBA accounting.
# Full DTLBA per-vehicle total = 20,984 bytes; NoDT = 24,712 bytes.
FULL_BYTES = 20984
NODT_BYTES = 24712
# Critical handover exchange uses handover request + target-RSU KEX response.
HANDOVER_REQ_BYTES = 10024
KEX_RESP_BYTES = 1600
CRITICAL_BYTES = HANDOVER_REQ_BYTES + KEX_RESP_BYTES


def mean_sd(xs):
    return (statistics.mean(xs), statistics.stdev(xs) if len(xs) > 1 else 0.0)


def pct(a,b):
    return 100.0*a/b if b else 0.0


def load_v3(v3_path: Path):
    import importlib.util
    spec = importlib.util.spec_from_file_location("dtlba_v3", v3_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import {v3_path}")
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    return m


def measure_processing(v3, rep: int, n_samples: int = 20):
    """Measure actual executable reference routines; no fixed operation-time constants."""
    full_ms=[]; handover_ms=[]; verify_ms=[]
    for j in range(n_samples):
        cert=v3.make_certificate(j, rep)
        t0=time.perf_counter_ns(); v3.individual_verify(cert); t1=time.perf_counter_ns()
        verify_ms.append((t1-t0)/1e6)
        seed=f"e2e-full-{rep}-{j}".encode()
        t0=time.perf_counter_ns(); v3.individual_verify(cert); v3.mlwr_kex(seed); t1=time.perf_counter_ns()
        full_ms.append((t1-t0)/1e6)
        # DT predictive work is already prepared; handover critical path = checks + fresh KEX.
        t0=time.perf_counter_ns(); v3.individual_verify(cert); v3.mlwr_kex(seed+b"ho"); t1=time.perf_counter_ns()
        handover_ms.append((t1-t0)/1e6)
    return statistics.mean(full_ms), statistics.mean(handover_ms), statistics.mean(verify_ms)


def packet_loss_for_density(density: int) -> float:
    # Explicit bounded stress profile, reported in output. This is a scenario parameter,
    # not a measured PHY claim. It rises smoothly from 0.5% to 5% at 800 vehicles.
    x=(density-min(DENSITIES))/(max(DENSITIES)-min(DENSITIES))
    return BASE_PACKET_LOSS + x*(MAX_PACKET_LOSS-BASE_PACKET_LOSS)


def simulate_link(density: int, bytes_per_auth: int, rng: random.Random, duration_s: float=30.0):
    """Packet-level FCFS discrete-event communication simulation.

    Authentication events arrive as a Poisson process. Each event is one serialized
    authentication payload. Failed transmissions are retried up to MAX_RETRIES.
    Queueing emerges from event overlap; it is not inserted as a closed-form delay.
    """
    lam=max(1e-9, density*AUTH_EVENT_RATE_PER_VEH_S)
    t=0.0; arrivals=[]
    while t < duration_s:
        t += rng.expovariate(lam)
        if t < duration_s: arrivals.append(t)
    channel_free=0.0; delays=[]; lost=0; attempts_total=0
    p_loss=packet_loss_for_density(density)
    for arrival in arrivals:
        attempts=0; success=False; done=arrival
        while attempts <= MAX_RETRIES and not success:
            attempts += 1; attempts_total += 1
            tx_ms=(bytes_per_auth*8)/(DATA_RATE_MBPS*1e6)*1000.0
            jitter=max(0.0, rng.gauss(0.0,JITTER_MS))
            service_ms=tx_ms+PROPAGATION_MS+BASE_MAC_MS+jitter
            start=max(arrival,channel_free)
            done=start+service_ms/1000.0
            channel_free=done
            if rng.random() >= p_loss:
                success=True
            else:
                lost += 1
                arrival=done
        delays.append((done-(arrivals[len(delays)]))*1000.0)
    return {
        "mean_comm_ms": statistics.mean(delays) if delays else 0.0,
        "p95_comm_ms": float(np.percentile(delays,95)) if delays else 0.0,
        "events": len(arrivals), "lost_attempts":lost, "attempts":attempts_total,
        "empirical_loss_pct":pct(lost,attempts_total), "configured_loss_pct":100*p_loss,
    }


def mobility_factor_from_csv(csv_path: Path, density: int):
    """Use observed SUMO load around each requested density to report supporting mobility counts."""
    if not csv_path.exists(): return 0, float('nan')
    rows=[]
    with csv_path.open(newline='',encoding='utf-8-sig') as f:
        for r in csv.DictReader(f):
            try:
                active=float(r.get('active_vehicles',''))
                rows.append(active)
            except: pass
    if not rows: return 0,float('nan')
    tol=max(10,0.15*density)
    near=[x for x in rows if abs(x-density)<=tol]
    return len(near), statistics.mean(near) if near else min(rows,key=lambda x:abs(x-density))


def maybe_run_sumo(args, outdir: Path):
    """Optional SUMO execution. Uses the user's existing v2 mobility script unchanged.
    Density-specific communication cases are then evaluated from observed active-load windows.
    """
    if not args.run_sumo: return Path(args.handover_csv)
    script=Path(args.mobility_script).resolve()
    if not script.exists(): raise FileNotFoundError(script)
    subprocess.run([sys.executable,str(script)],cwd=script.parent,check=True)
    produced=script.parent/'dt_handover_events_v2.csv'
    if not produced.exists(): raise FileNotFoundError(produced)
    return produced


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--v3',default='DTLBA_ablation_experiment_v3.py')
    ap.add_argument('--handover-csv',default='dt_handover_events_v2.csv')
    ap.add_argument('--run-sumo',action='store_true')
    ap.add_argument('--mobility-script',default='DTLBA_dt_prediction_mobility_v2.py')
    ap.add_argument('--outdir',default='e2e_density_results')
    args=ap.parse_args()
    base=Path.cwd(); out=base/args.outdir; out.mkdir(parents=True,exist_ok=True)
    v3_path=(base/args.v3).resolve(); v3=load_v3(v3_path)
    handover_csv=maybe_run_sumo(args,out)
    if not handover_csv.is_absolute(): handover_csv=(base/handover_csv).resolve()

    raw=[]; comm_rows=[]
    for density in DENSITIES:
        windows, observed=mobility_factor_from_csv(handover_csv,density)
        for rep in range(REPETITIONS):
            full_proc,ho_proc,verify=measure_processing(v3,rep,n_samples=10)
            rng=random.Random(SEED+density*1000+rep)
            # Full-DTLBA total communication and critical handover communication.
            ctot=simulate_link(density,FULL_BYTES,rng)
            ccrit=simulate_link(density,CRITICAL_BYTES,rng)
            # NoDT uses full post-arrival auth exchange.
            c_nodt=simulate_link(density,NODT_BYTES,rng)
            e2e_full=ho_proc+ccrit['mean_comm_ms']
            e2e_nodt=full_proc+c_nodt['mean_comm_ms']
            # Completed auth/s from latency is not used; throughput is actual completed
            # communication events per 30-s simulation window, limited by processing capacity.
            net_thr=ctot['events']/30.0
            proc_thr=1000.0/max(verify,1e-9)
            throughput=min(net_thr,proc_thr)
            raw.append(dict(density=density,rep=rep+1,sumo_windows_near_density=windows,
                observed_mean_active=observed,processing_full_ms=full_proc,
                handover_critical_processing_ms=ho_proc,verification_ms=verify,
                communication_full_ms=ctot['mean_comm_ms'],communication_critical_ms=ccrit['mean_comm_ms'],
                communication_nodt_ms=c_nodt['mean_comm_ms'],e2e_full_ms=e2e_full,e2e_nodt_ms=e2e_nodt,
                throughput_auth_s=throughput,configured_packet_loss_pct=ctot['configured_loss_pct'],
                empirical_packet_loss_pct=ctot['empirical_loss_pct'],communication_bytes=FULL_BYTES))
            comm_rows.append(dict(density=density,rep=rep+1,events=ctot['events'],attempts=ctot['attempts'],
                lost_attempts=ctot['lost_attempts'],configured_loss_pct=ctot['configured_loss_pct'],
                empirical_loss_pct=ctot['empirical_loss_pct'],mean_comm_ms=ctot['mean_comm_ms'],p95_comm_ms=ctot['p95_comm_ms']))

    def write_csv(path,rows):
        with path.open('w',newline='',encoding='utf-8') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    write_csv(out/'e2e_density_repetitions.csv',raw); write_csv(out/'e2e_density_communication.csv',comm_rows)

    overall=[]
    for d in DENSITIES:
        rr=[r for r in raw if r['density']==d]
        row={'density':d,'sumo_windows_near_density':rr[0]['sumo_windows_near_density'],'observed_mean_active':rr[0]['observed_mean_active']}
        for key in ['processing_full_ms','handover_critical_processing_ms','verification_ms','communication_full_ms','communication_critical_ms','e2e_full_ms','e2e_nodt_ms','throughput_auth_s','empirical_packet_loss_pct']:
            m,s=mean_sd([float(r[key]) for r in rr]); row[key+'_mean']=m; row[key+'_sd']=s
        row['dt_e2e_reduction_pct']=100*(row['e2e_nodt_ms_mean']-row['e2e_full_ms_mean'])/row['e2e_nodt_ms_mean']
        row['communication_bytes']=FULL_BYTES
        overall.append(row)
    write_csv(out/'e2e_density_overall.csv',overall)

    # Figures: default Matplotlib styling, no forced colors.
    import matplotlib.pyplot as plt
    x=[r['density'] for r in overall]
    def fig(ykeys,labels,ylabel,name):
        plt.figure(figsize=(7,4.5))
        for k,l in zip(ykeys,labels): plt.plot(x,[r[k] for r in overall],marker='o',label=l)
        plt.xlabel('Active vehicles'); plt.ylabel(ylabel); plt.grid(True,alpha=.25)
        if len(ykeys)>1: plt.legend()
        plt.tight_layout(); plt.savefig(out/name,dpi=300); plt.close()
    fig(['e2e_full_ms_mean','e2e_nodt_ms_mean'],['Full DTLBA','DTLBA-NoDT'],'End-to-end latency, ms','fig_e2e_latency_vs_density.png')
    fig(['throughput_auth_s_mean'],['Full DTLBA'],'Throughput, authentications/s','fig_e2e_throughput_vs_density.png')
    fig(['handover_critical_processing_ms_mean','communication_critical_ms_mean'],['Processing','Communication'],'Critical-path component delay, ms','fig_e2e_components_vs_density.png')
    fig(['empirical_packet_loss_pct_mean'],['Packet loss'],'Packet loss, %','fig_e2e_packet_loss_vs_density.png')

    with (out/'e2e_density_summary.txt').open('w',encoding='utf-8') as f:
        f.write('DTLBA end-to-end density experiment\n')
        f.write(f'Densities={DENSITIES}; repetitions={REPETITIONS}\n')
        f.write(f'Link: {DATA_RATE_MBPS} Mbps, propagation={PROPAGATION_MS} ms, base MAC={BASE_MAC_MS} ms, jitter SD={JITTER_MS} ms\n')
        f.write(f'Packet-loss scenario: {BASE_PACKET_LOSS*100:.2f}% to {MAX_PACKET_LOSS*100:.2f}%; max retries={MAX_RETRIES}\n')
        f.write(f'Auth event rate={AUTH_EVENT_RATE_PER_VEH_S} per vehicle/s\n')
        f.write('Communication latency is packet-level simulated, not physical-radio measured.\n')
        f.write(f'Mobility source={handover_csv}\n')
    print('\nCompleted. Results:',out.resolve())
    for r in overall:
        print(f"{r['density']:4d} vehicles | E2E full {r['e2e_full_ms_mean']:.3f} ms | NoDT {r['e2e_nodt_ms_mean']:.3f} ms | throughput {r['throughput_auth_s_mean']:.2f}/s | loss {r['empirical_packet_loss_pct_mean']:.2f}%")

if __name__=='__main__': main()
