# ============================================================
# FINAL INTEGRATED SUMO + COMPARISON SCRIPT
# File name: integrated_sumo_compare.py
# ============================================================

import os
import sys
import csv
from pathlib import Path
from typing import Dict, List

import matplotlib.pyplot as plt
import traci


# ============================================================
# USER SETTINGS
# ============================================================
SUMO_GUI = True
NET_FILE = "mynet.net.xml"
ROUTE_FILE = "routes.rou.xml"
SIM_LOG_CSV = "simulation_log.csv"
STEP_LIMIT = 200

# RSU zones along x-axis
ZONE_1_END = 300.0
ZONE_2_END = 700.0

# Batch threshold
BATCH_GROUP_SIZE = 5

# DSRC Parameters
DATA_RATE_BPS = 6_000_000      # 6 Mbps
CPU_POWER_W = 10.88
TX_POWER_W = 10.88


# ============================================================
# OPERATION COSTS (Proposed Scheme) in ms
# ============================================================
T_PM = 208.4999
T_PA = 0.088692
T_RND = 0.067234
T_SM = 0.026891
T_SPL = 0.075322
T_CHA = 0.311136
T_MOD = 0.604391
T_H = 0.073671
T_SYM = 0.046492
T_FE = 0.020266
T_XOR = 0.065804


# ============================================================
# COMPARISON SCHEMES
# ============================================================
SCHEMES = {
    "Huang": {
        "comp_vehicle_ms": 627.831584,
        "comp_edge_ms": 627.684242,
        "comm_bytes": 3568,
    },
    "Liu": {
        "comp_vehicle_ms": 1253.331133,
        "comp_edge_ms": 1253.331133,
        "comm_bytes": 6336,
    },
    "Yan": {
        "comp_vehicle_ms": 417.604189,
        "comp_edge_ms": 1668.824602,
        "comm_bytes": 4672,
    },
    "Ahmed": {
        "comp_vehicle_ms": 2506.893294,
        "comp_edge_ms": 2297.272588,
        "comm_bytes": 4736,
    },
    "Proposed": {
        "comp_vehicle_ms": 417.443973,
        "comp_edge_ms": 417.474015,
        "comm_bytes": 4352,
    },
}


# ============================================================
# HELPERS
# ============================================================
def avg(values):
    return sum(values) / len(values) if values else 0.0


def get_sumo_binary():
    sumo_home = os.environ.get("SUMO_HOME")
    if not sumo_home:
        raise EnvironmentError("SUMO_HOME not set")

    tools = os.path.join(sumo_home, "tools")
    if tools not in sys.path:
        sys.path.append(tools)

    return "sumo-gui" if SUMO_GUI else "sumo"


def ensure_required_files():
    missing = []
    for file_name in [NET_FILE, ROUTE_FILE]:
        if not Path(file_name).exists():
            missing.append(file_name)
    if missing:
        raise FileNotFoundError(f"Missing required SUMO files: {missing}")


def communication_delay_ms(comm_bytes):
    return (comm_bytes * 8 / DATA_RATE_BPS) * 1000.0


def total_computation_ms(comp_v, comp_e):
    return comp_v + comp_e


def total_auth_delay_ms(comp_v, comp_e, comm_bytes):
    return comp_v + comp_e + communication_delay_ms(comm_bytes)


def energy_comp_j(ms):
    return (ms / 1000.0) * CPU_POWER_W


def energy_comm_j(comm_bytes):
    return (comm_bytes * 8 * TX_POWER_W) / DATA_RATE_BPS


def get_zone(x):
    if x < ZONE_1_END:
        return 1
    elif x < ZONE_2_END:
        return 2
    return 3


def effective_delay(base_delay, density, speed):
    density_factor = 1 + density / 100.0
    speed_factor = 1 + speed / 100.0
    return base_delay * density_factor / speed_factor


def effective_throughput(base_throughput, scheme_delay, min_delay):
    if scheme_delay <= 0:
        return base_throughput
    return base_throughput * (min_delay / scheme_delay)


def plot_bar(labels, values, ylabel, title, filename):
    plt.figure(figsize=(8, 5))
    plt.bar(labels, values)
    plt.ylabel(ylabel)
    plt.title(title)
    plt.xticks(rotation=20)
    plt.tight_layout()
    plt.savefig(filename, dpi=300)
    plt.close()


def plot_line(x, y, xlabel, ylabel, title, filename):
    plt.figure(figsize=(8, 5))
    plt.plot(x, y, marker='o')
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.title(title)
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(filename, dpi=300)
    plt.close()


# ============================================================
# PROPOSED COST MODELS
# ============================================================
def normal_auth_ms():
    return 2 * (T_PM + T_RND) + 3 * T_H + T_PA


def predictive_auth_ms():
    return T_H + T_PA


def handover_auth_ms():
    return (T_PM + T_RND) + T_H + 2 * T_PA


def batch_auth_ms(n):
    return n * (T_H + 4 * T_PA) + 2 * (T_PM + T_RND)


# ============================================================
# SUMO SIMULATION
# ============================================================
def run_sumo():
    ensure_required_files()
    binary = get_sumo_binary()

    cmd = [
        binary,
        "-n", NET_FILE,
        "-r", ROUTE_FILE,
        "--start",
        "--quit-on-end",
        "--step-length", "1.0"
    ]

    traci.start(cmd)

    rows = []
    auth_cost = 0.0
    vehicle_zone = {}

    try:
        for step in range(STEP_LIMIT):
            traci.simulationStep()

            veh_ids = traci.vehicle.getIDList()
            speeds = []

            normal_count = 0
            handover_count = 0
            predictive_count = 0
            batch_count = 0

            for vid in veh_ids:
                speed = traci.vehicle.getSpeed(vid)
                x, _ = traci.vehicle.getPosition(vid)
                speeds.append(speed)

                zone = get_zone(x)

                if vid not in vehicle_zone:
                    vehicle_zone[vid] = zone
                    normal_count += 1
                    auth_cost += normal_auth_ms()
                else:
                    old = vehicle_zone[vid]

                    if zone != old:
                        handover_count += 1
                        auth_cost += handover_auth_ms()
                        vehicle_zone[vid] = zone
                    elif speed > 5:
                        predictive_count += 1
                        auth_cost += predictive_auth_ms()

            if len(veh_ids) >= BATCH_GROUP_SIZE:
                batch_count = len(veh_ids) // BATCH_GROUP_SIZE
                auth_cost += batch_auth_ms(batch_count)

            # Simple density proxy for the designated area
            density = len(veh_ids) / 5.0
            throughput = traci.simulation.getArrivedNumber()

            rows.append({
                "step": step,
                "vehicles": len(veh_ids),
                "speed": avg(speeds) * 3.6,
                "density": density,
                "throughput": throughput,
                "auth_cost": auth_cost
            })
    finally:
        traci.close()

    with open(SIM_LOG_CSV, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)

    return rows


# ============================================================
# GENERATE SUMO GRAPHS
# ============================================================
def sumo_graphs(rows):
    step = [r["step"] for r in rows]
    speed = [r["speed"] for r in rows]
    density = [r["density"] for r in rows]
    throughput = [r["throughput"] for r in rows]
    auth = [r["auth_cost"] for r in rows]

    plot_line(step, speed, "Step", "km/h", "Speed vs Time", "speed_vs_time.png")
    plot_line(step, density, "Step", "Veh/km", "Density vs Time", "density_vs_time.png")
    plot_line(step, throughput, "Step", "Vehicles", "Throughput vs Time", "throughput_vs_time.png")
    plot_line(step, auth, "Step", "ms", "Authentication Cost vs Time", "auth_cost_vs_time.png")


# ============================================================
# COMPARISON GRAPHS
# ============================================================
def comparison_graphs(rows):
    avg_density = avg([r["density"] for r in rows])
    avg_speed = avg([r["speed"] for r in rows])
    avg_throughput = avg([r["throughput"] for r in rows])

    names = []
    comp = []
    comm = []
    delay = []
    sumo_delay = []
    energy = []
    throughput_values = []

    raw_delays = []
    for _, val in SCHEMES.items():
        d = total_auth_delay_ms(
            val["comp_vehicle_ms"],
            val["comp_edge_ms"],
            val["comm_bytes"]
        )
        raw_delays.append(d)

    min_delay = min(raw_delays)

    for name, val in SCHEMES.items():
        c = total_computation_ms(val["comp_vehicle_ms"], val["comp_edge_ms"])
        m = val["comm_bytes"]
        d = total_auth_delay_ms(val["comp_vehicle_ms"], val["comp_edge_ms"], m)
        sd = effective_delay(d, avg_density, avg_speed)
        e = energy_comp_j(c) + energy_comm_j(m)
        th = effective_throughput(avg_throughput, d, min_delay)

        names.append(name)
        comp.append(c)
        comm.append(m)
        delay.append(d)
        sumo_delay.append(sd)
        energy.append(e)
        throughput_values.append(th)

        print(f"{name}")
        print("Computation =", round(c, 4), "ms")
        print("Communication =", m, "bytes")
        print("Total Delay =", round(d, 4), "ms")
        print("SUMO Delay =", round(sd, 4), "ms")
        print("Energy =", round(e, 4), "J")
        print("Throughput =", round(th, 4), "veh/step")
        print()

    plot_bar(names, comp, "ms", "Computation Cost Comparison", "comparison_computation.png")
    plot_bar(names, comm, "bytes", "Communication Cost Comparison", "comparison_communication.png")
    plot_bar(names, delay, "ms", "Authentication Delay Comparison", "comparison_delay.png")
    plot_bar(names, sumo_delay, "ms", "SUMO Practical Delay Comparison", "comparison_sumo_delay.png")
    plot_bar(names, energy, "J", "Energy Comparison", "comparison_energy.png")
    plot_bar(names, throughput_values, "Vehicles/step", "Throughput Comparison", "comparison_throughput.png")


# ============================================================
# MAIN
# ============================================================
def main():
    print("Running SUMO Simulation...")
    rows = run_sumo()

    print("Generating SUMO Graphs...")
    sumo_graphs(rows)

    print("Generating Comparison Graphs...")
    comparison_graphs(rows)

    print("All files generated successfully.")
    print("Generated files:")
    print(" - simulation_log.csv")
    print(" - speed_vs_time.png")
    print(" - density_vs_time.png")
    print(" - throughput_vs_time.png")
    print(" - auth_cost_vs_time.png")
    print(" - comparison_computation.png")
    print(" - comparison_communication.png")
    print(" - comparison_delay.png")
    print(" - comparison_sumo_delay.png")
    print(" - comparison_energy.png")
    print(" - comparison_throughput.png")


if __name__ == "__main__":
    main()