"""DTLBA component-wise ablation benchmark (v3).

Faithfully benchmarks the *operation structure* of the revised DTLBA equations:
  - MLWR matrix-vector multiply + q->p rounding
  - predictive MLWR secret establishment with HelpRec/Rec-shaped reconciliation
  - handover checks and fresh MLWR secret establishment
  - individual verification versus the manuscript's aggregate batch equations
  - communication bytes from explicitly serialized protocol fields

This is a reproducible Python/Numpy reference implementation for ablation timing,
NOT a production cryptographic implementation and NOT a security parameter estimator.
The manuscript's exact reconciliation coding and final signature redesign must replace
those components before claiming cryptographic implementation-level security.

Outputs:
  ablation_v3_overall.csv
  ablation_v3_batch_scalability.csv
  ablation_v3_wrong_prediction.csv
  ablation_v3_repetitions.csv
  ablation_v3_communication.csv
  ablation_v3_summary.txt

Optional SUMO inputs in the same folder:
  dt_prediction_events_v2.csv
  dt_handover_events_v2.csv
"""
from __future__ import annotations
import csv, hashlib, math, statistics, time
from pathlib import Path
import numpy as np

SEED = 20260917
REPETITIONS = 30
BATCH_SIZES = [10, 25, 50, 100]
DEFAULT_BATCH = 50

# Current manuscript parameters where explicitly stated.
N = 512                 # ring degree
K = 3                   # module rank; set to final manuscript value if changed
Q = 12289
P = 256
ETA = 3                 # small-secret width for executable reference benchmark
HASH_BYTES = 32
TIME_BYTES = 8
RSU_ID_BYTES = 4
MSG_BYTES = 32
RECON_BYTES = math.ceil(N / 8)  # one reconciliation/helper bit per coefficient

# R_p module-vector serialization (K polynomials, N coeffs, log2(P) bits each)
RP_VEC_BYTES = math.ceil(K * N * math.ceil(math.log2(P)) / 8)
# R_q module-vector serialization
RQ_VEC_BYTES = math.ceil(K * N * math.ceil(math.log2(Q)) / 8)

PRED_CSV = Path("dt_prediction_events_v2.csv")
HANDOVER_CSV = Path("dt_handover_events_v2.csv")


def H(data: bytes) -> bytes:
    return hashlib.sha3_256(data).digest()


def hash_to_small(tag: bytes, shape):
    """Deterministically map a tag to small coefficients for reproducibility."""
    seed = int.from_bytes(H(tag)[:8], "big")
    rng = np.random.default_rng(seed)
    return rng.integers(-ETA, ETA + 1, size=shape, dtype=np.int64)


def public_matrix():
    rng = np.random.default_rng(SEED)
    # Reference coefficient-domain module matrix. For timing reproducibility this
    # performs dense modular module arithmetic; production code should use NTT/Toom-Cook.
    return rng.integers(0, Q, size=(K, K, N), dtype=np.int64)

A = public_matrix()


def module_matvec(A3, s):
    """Coefficient-wise reference module multiplication over R_q.

    This preserves the manuscript's k x k module-matrix/vector operation count.
    It is deliberately a reference benchmark, not an optimized polynomial-ring backend.
    """
    # Each coefficient position carries a KxK modular multiply.
    out = np.einsum('ijn,jn->in', A3, s, optimize=True)
    return np.remainder(out, Q)


def round_q_to_p(x):
    # nearest-integer scaling q -> p
    return np.remainder(((np.remainder(x, Q) * P + Q // 2) // Q), P).astype(np.int64)


def mlwr_public(secret):
    return round_q_to_p(module_matvec(A, secret))


def hash_to_module(data: bytes):
    return np.remainder(hash_to_small(data, (K, N)), Q)


def inner_module(pub_p, secret_q):
    # Reference shared material used by V_i=Y_j^T r_i / V_j=Y_i^T r_j.
    # Lift rounded public coefficients approximately back to q-domain.
    lifted = (pub_p.astype(np.int64) * Q) // P
    return np.remainder(np.sum(lifted * secret_q, axis=0), Q)


def help_rec(v):
    """One-bit helper around q/4 boundaries (reference reconciliation shape)."""
    return ((np.remainder(v, Q) + Q // 8) // (Q // 4) & 1).astype(np.uint8)


def rec(v, c):
    """Derive 256-bit key material from reconciled coefficient decisions."""
    bits = (((np.remainder(v, Q) + (c.astype(np.int64) * (Q // 8))) // (Q // 2)) & 1).astype(np.uint8)
    packed = np.packbits(bits).tobytes()
    return H(packed)


def mlwr_kex(seed: bytes):
    """Revised secret-bearing KEX: Yi=Ari, Yj=A^T rj, Vi=Yj^T ri, Vj=Yi^T rj, c, Rec."""
    ri = hash_to_small(seed + b"ri", (K, N))
    rj = hash_to_small(seed + b"rj", (K, N))
    Yi = mlwr_public(ri)
    # A^T in module dimensions
    Yj = round_q_to_p(module_matvec(np.swapaxes(A, 0, 1), rj))
    Vi = inner_module(Yj, ri)
    Vj = inner_module(Yi, rj)
    c = help_rec(Vj)
    Ki = rec(Vi, c)
    Kj = rec(Vj, c)
    # In a concrete KEX the reconciliation design/parameters ensure agreement except epsilon_rec.
    # For timing, bind both computations; do not silently assert equality in this reference backend.
    transcript = H(seed + Yi.astype(np.uint16).tobytes() + Yj.astype(np.uint16).tobytes())
    sk = H(Ki + Kj + transcript)
    return sk, Yi, Yj, c


def make_certificate(i: int, rep: int):
    """Construct arrays matching D_i,K_i,Y_i,T_i,lambda_i,delta_i,M_i,Sig_i fields."""
    tag = f"cert-{rep}-{i}".encode()
    alpha = hash_to_small(tag+b"a", (K,N)); beta = hash_to_small(tag+b"b", (K,N)); r = hash_to_small(tag+b"r", (K,N))
    l = hash_to_small(b"TA-l", (K,N))
    D = mlwr_public(alpha + l)
    K_i = mlwr_public(-alpha)
    I = mlwr_public(l)
    T = mlwr_public(alpha + beta)
    Y = mlwr_public(r)
    lam = np.remainder(alpha + r, Q)
    delta = np.remainder(r - beta, Q)
    M = H(tag+b"M")
    hm = hash_to_module(M)
    Sig = mlwr_public(r + hm)
    return dict(D=D,K=K_i,I=I,T=T,Y=Y,lam=lam,delta=delta,M=M,hm=hm,Sig=Sig)


def infnorm_mod_p(x):
    z = np.remainder(x, P)
    z = np.minimum(z, P-z)
    return int(np.max(np.abs(z)))


def individual_verify(cert):
    """Manuscript verification operation structure: identity + token + signature."""
    id_res = cert['D'] + cert['K'] - cert['I']
    token_prime = mlwr_public(cert['lam'] - cert['delta'])
    hm_term = mlwr_public(cert['hm'])
    sig_res = cert['Sig'] - (cert['Y'] + hm_term)
    # Threshold values are not used to tune timings; return norms for auditability.
    return infnorm_mod_p(id_res), infnorm_mod_p(token_prime-cert['T']), infnorm_mod_p(sig_res)


def batch_verify(certs, rep: int):
    """Implements the three aggregate equations currently specified in DTLBA.

    Uses random nonzero coefficients omega_i (renamed to avoid alpha_i credential collision):
      S1=sum omega Sig; S2=sum omega Y; S3=sum omega H(M)
      check S1-(S2+round(A S3))
      check sum omega(D+K-I)
      S4=sum omega(lambda-delta); S5=sum omega T; check round(A S4)-S5
    Thus only TWO expensive MLWR matvec+round operations are performed for the batch.
    """
    rng = np.random.default_rng(SEED + 10000 + rep + len(certs))
    omega = rng.integers(1, P, size=len(certs), dtype=np.int64)
    S1 = np.zeros((K,N), dtype=np.int64); S2 = np.zeros((K,N), dtype=np.int64)
    S3 = np.zeros((K,N), dtype=np.int64); Sid = np.zeros((K,N), dtype=np.int64)
    S4 = np.zeros((K,N), dtype=np.int64); S5 = np.zeros((K,N), dtype=np.int64)
    for w,c in zip(omega, certs):
        S1 += w*c['Sig']; S2 += w*c['Y']; S3 += w*c['hm']
        Sid += w*(c['D']+c['K']-c['I'])
        S4 += w*(c['lam']-c['delta']); S5 += w*c['T']
    sig_term = mlwr_public(S3)
    token_term = mlwr_public(S4)
    return infnorm_mod_p(S1-(S2+sig_term)), infnorm_mod_p(Sid), infnorm_mod_p(token_term-S5)


def handover_checks(cert, seed: bytes):
    """HT check + T'' reconstruction + D+K-I + fresh revised MLWR KEX."""
    th = int.from_bytes(H(seed+b"time")[:8], 'big').to_bytes(8,'big')
    HT = H(cert['D'].astype(np.uint16).tobytes()+cert['T'].astype(np.uint16).tobytes()+cert['Y'].astype(np.uint16).tobytes()+th)
    HT2 = H(cert['D'].astype(np.uint16).tobytes()+cert['T'].astype(np.uint16).tobytes()+cert['Y'].astype(np.uint16).tobytes()+th)
    token_prime = mlwr_public(cert['lam']-cert['delta'])
    _ = infnorm_mod_p(token_prime-cert['T'])
    _ = infnorm_mod_p(cert['D']+cert['K']-cert['I'])
    sk, Yi, Yj, c = mlwr_kex(seed+b"ho")
    return HT == HT2 and bool(sk), Yi, Yj, c


def predictive_prep(cert, seed: bytes):
    """psi, rho, P_i^tau, HT_i^tau plus revised MLWR KEX material preparation."""
    tau = int.from_bytes(H(seed+b"tau")[:8], 'big').to_bytes(8,'big')
    rsu = b"R002"
    mu = H(cert['M'])
    psi = H(cert['D'].astype(np.uint16).tobytes()+cert['T'].astype(np.uint16).tobytes()+rsu+tau+mu)
    rho = hash_to_module(H(psi + cert['Y'].astype(np.uint16).tobytes()))
    Ptau = mlwr_public(rho)
    HT = H(cert['D'].astype(np.uint16).tobytes()+Ptau.astype(np.uint16).tobytes()+rsu+tau)
    sk, Yi, Yj, c = mlwr_kex(seed+b"pred")
    return Ptau, HT, sk, Yi, Yj, c


def measure_ms(fn, *args):
    t0=time.perf_counter_ns(); out=fn(*args); return out,(time.perf_counter_ns()-t0)/1e6


def load_sumo_stats():
    out={'accuracy_pct':float('nan'),'mean_lead_s':float('nan'),'mean_inference_ms':float('nan'),'resolved':0,'wrong':0,'handovers':0}
    if PRED_CSV.exists():
        rows=list(csv.DictReader(PRED_CSV.open(newline='',encoding='utf-8-sig')))
        resolved=[r for r in rows if r.get('status') in ('correct','wrong')]
        correct=[r for r in resolved if r.get('status')=='correct']; wrong=[r for r in resolved if r.get('status')=='wrong']
        leads=[float(r['lead_time_s']) for r in resolved if r.get('lead_time_s')]
        inf=[float(r['inference_ms']) for r in rows if r.get('inference_ms')]
        out.update(resolved=len(resolved),wrong=len(wrong),accuracy_pct=100*len(correct)/len(resolved) if resolved else float('nan'),mean_lead_s=statistics.mean(leads) if leads else float('nan'),mean_inference_ms=statistics.mean(inf) if inf else float('nan'))
    if HANDOVER_CSV.exists(): out['handovers']=sum(1 for _ in csv.DictReader(HANDOVER_CSV.open(newline='',encoding='utf-8-sig')))
    return out


def communication_bytes():
    """Byte accounting from revised message fields; batch itself adds no uplink bytes."""
    # Cert={K,D,Y,T,lambda,delta,M,Sig}: five R_p vectors (K,D,Y,T,Sig), two R_q vectors, M
    cert = 5*RP_VEC_BYTES + 2*RQ_VEC_BYTES + MSG_BYTES
    # Predictive request Req=(D,Y,P,HT,tau)
    pred_req = 3*RP_VEC_BYTES + HASH_BYTES + TIME_BYTES
    # Current->target context=(D,P,HT,tau)
    pred_forward = 2*RP_VEC_BYTES + HASH_BYTES + TIME_BYTES
    # Revised target->vehicle KEX response=(Y_j,c)
    pred_kex_response = RP_VEC_BYTES + RECON_BYTES
    # HReq=(D,Y,K,lambda,delta,HT,t_h)
    hand_req = 3*RP_VEC_BYTES + 2*RQ_VEC_BYTES + HASH_BYTES + TIME_BYTES
    # Revised target RSU response=(Y_{j+1},c^ho)
    hand_kex_response = RP_VEC_BYTES + RECON_BYTES
    return dict(full_auth=cert,predictive_request=pred_req,predictive_forward=pred_forward,predictive_kex_response=pred_kex_response,handover_request=hand_req,handover_kex_response=hand_kex_response)


def benchmark_one(rep, batch_size=DEFAULT_BATCH):
    certs=[make_certificate(i,rep) for i in range(batch_size)]
    c0=certs[0]
    # NoDT: handover-critical path must do full individual authentication + fresh KEX after arrival.
    t0=time.perf_counter_ns(); individual_verify(c0); handover_checks(c0,f"nodt-{rep}".encode()); nodt=(time.perf_counter_ns()-t0)/1e6
    # Full: predictive preparation is done before arrival; handover-critical path contains only handover checks + fresh KEX.
    _, prep_ms=measure_ms(predictive_prep,c0,f"full-{rep}".encode())
    _, full_ho=measure_ms(handover_checks,c0,f"full-{rep}".encode())
    # Verification ablation on identical batch.
    t=time.perf_counter_ns();
    for c in certs: individual_verify(c)
    indiv=(time.perf_counter_ns()-t)/1e6
    _,batch_ms=measure_ms(batch_verify,certs,rep)
    return dict(repetition=rep+1,batch_size=batch_size,nodt_handover_ms=nodt,full_handover_ms=full_ho,predictive_prep_ms=prep_ms,individual_verification_ms=indiv,batch_verification_ms=batch_ms,individual_throughput_auth_s=batch_size/(indiv/1000),batch_throughput_auth_s=batch_size/(batch_ms/1000))


def mean_sd(vals): return statistics.mean(vals), statistics.stdev(vals) if len(vals)>1 else 0.0

def write_csv(path,rows):
    with open(path,'w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)


def main():
    raw=[benchmark_one(r) for r in range(REPETITIONS)]
    write_csv('ablation_v3_repetitions.csv',raw)
    # Overall three configurations. NoBatch and Full have same DT handover critical path; they differ in verification mode/throughput.
    configs=[]
    specs=[('DTLBA-NoDT','nodt_handover_ms','batch_verification_ms','batch_throughput_auth_s'),('DTLBA-NoBatch','full_handover_ms','individual_verification_ms','individual_throughput_auth_s'),('Full DTLBA','full_handover_ms','batch_verification_ms','batch_throughput_auth_s')]
    comm=communication_bytes()
    for name,hcol,vcol,tcol in specs:
        hm,hs=mean_sd([r[hcol] for r in raw]); vm,vs=mean_sd([r[vcol] for r in raw]); tm,ts=mean_sd([r[tcol] for r in raw])
        # Batch toggle does not change per-vehicle uplink. DT adds predictive exchange, but that is pre-handover traffic.
        if name=='DTLBA-NoDT': bytes_auth=comm['full_auth']+comm['handover_request']+comm['handover_kex_response']
        else: bytes_auth=comm['predictive_request']+comm['predictive_forward']+comm['predictive_kex_response']+comm['handover_request']+comm['handover_kex_response']
        configs.append(dict(configuration=name,handover_delay_mean_ms=round(hm,6),handover_delay_sd_ms=round(hs,6),verification_mean_ms=round(vm,6),verification_sd_ms=round(vs,6),throughput_mean_auth_s=round(tm,3),throughput_sd_auth_s=round(ts,3),communication_bytes_per_vehicle=bytes_auth))
    write_csv('ablation_v3_overall.csv',configs)

    batch_rows=[]
    for n in BATCH_SIZES:
        iv=[];bv=[]
        for rep in range(REPETITIONS):
            certs=[make_certificate(i,1000+rep) for i in range(n)]
            t=time.perf_counter_ns();
            for c in certs: individual_verify(c)
            iv.append((time.perf_counter_ns()-t)/1e6)
            _,x=measure_ms(batch_verify,certs,2000+rep); bv.append(x)
        im,is_=mean_sd(iv); bm,bs=mean_sd(bv)
        batch_rows.append(dict(batch_size=n,individual_mean_ms=round(im,6),individual_sd_ms=round(is_,6),batch_mean_ms=round(bm,6),batch_sd_ms=round(bs,6),individual_throughput_auth_s=round(n/(im/1000),3),batch_throughput_auth_s=round(n/(bm/1000),3),batch_time_reduction_pct=round(100*(im-bm)/im,3)))
    write_csv('ablation_v3_batch_scalability.csv',batch_rows)

    # Wrong prediction: wasted predictive prep at wrong RSU + normal arrival path at actual RSU.
    wrong=[]
    for rep in range(REPETITIONS):
        c=make_certificate(0,3000+rep)
        _,correct=measure_ms(handover_checks,c,f"correct-{rep}".encode())
        _,wasted=measure_ms(predictive_prep,c,f"wrong-{rep}".encode())
        t=time.perf_counter_ns(); individual_verify(c); handover_checks(c,f"recover-{rep}".encode()); recovery=(time.perf_counter_ns()-t)/1e6
        wrong.append(dict(repetition=rep+1,correct_prediction_handover_ms=correct,wasted_preparation_ms=wasted,wrong_prediction_recovery_ms=recovery,wrong_prediction_total_processing_ms=wasted+recovery,recovery_penalty_critical_ms=recovery-correct))
    write_csv('ablation_v3_wrong_prediction.csv',wrong)

    comm_rows=[{'phase':k,'bytes':v} for k,v in comm.items()]
    write_csv('ablation_v3_communication.csv',comm_rows)
    sumo=load_sumo_stats()
    with open('ablation_v3_summary.txt','w',encoding='utf-8') as f:
        f.write('DTLBA v3 ablation benchmark\n')
        f.write(f'Parameters: N={N}, K={K}, q={Q}, p={P}, repetitions={REPETITIONS}\n')
        f.write(f'SUMO resolved={sumo["resolved"]}, accuracy={sumo["accuracy_pct"]:.4f}%, wrong={sumo["wrong"]}, mean lead={sumo["mean_lead_s"]:.4f}s\n')
        f.write('IMPORTANT: reference Numpy MLWR arithmetic; replace reconciliation/signature backend with final audited implementation for cryptographic implementation claims.\n')
    print('Completed DTLBA ablation v3.')
    for r in configs: print(r)
    print('Generated: ablation_v3_overall.csv, ablation_v3_batch_scalability.csv, ablation_v3_wrong_prediction.csv, ablation_v3_repetitions.csv, ablation_v3_communication.csv, ablation_v3_summary.txt')

if __name__=='__main__': main()
