import csv
import os
import matplotlib

# Force backend (no GUI needed)
matplotlib.use('Agg')
import matplotlib.pyplot as plt

FILE = r"D:\sumo_projects\first_sim\simulation_log.csv"

print("Reading CSV from:", FILE)

steps = []
speeds = []
vehicles = []
throughput = []

# -------- READ DATA --------
try:
    with open(FILE, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            steps.append(int(row["Step"]))
            vehicles.append(int(row["Vehicle_Count"]))
            speeds.append(float(row["Avg_Speed"]))
            throughput.append(float(row["Throughput"]))

    print("CSV data loaded successfully")

except Exception as e:
    print("Error reading CSV:", e)
    exit()

# -------- CHECK DATA --------
if len(steps) == 0:
    print("CSV is empty — no graphs generated")
    exit()

# -------- CREATE GRAPHS --------
try:
    # Speed Graph
    plt.figure()
    plt.plot(steps, speeds)
    plt.xlabel("Time Step")
    plt.ylabel("Average Speed")
    plt.title("Speed vs Time")
    plt.grid()
    plt.savefig("speed.png")
    print("Saved speed.png")

    # Density Graph
    plt.figure()
    plt.plot(steps, vehicles)
    plt.xlabel("Time Step")
    plt.ylabel("Vehicle Count")
    plt.title("Vehicle Density")
    plt.grid()
    plt.savefig("density.png")
    print("Saved density.png")

    # Throughput Graph
    plt.figure()
    plt.plot(steps, throughput)
    plt.xlabel("Time Step")
    plt.ylabel("Throughput")
    plt.title("Throughput vs Time")
    plt.grid()
    plt.savefig("throughput.png")
    print("Saved throughput.png")

    print("\nAll graphs generated successfully!")

except Exception as e:
    print("Graph generation error:", e)