import csv
from pathlib import Path
import matplotlib.pyplot as plt

SIM_LOG_CSV = "simulation_log.csv"

SCHEMES = {
    "Huang et al. (w1)": {
        "comp_vehicle_ms": 627.831584,
        "comp_edge_ms": 627.684242,
        "comm_bytes": 3568,
    },
    "Liu et al. (w2)": {
        "comp_vehicle_ms": 1253.331133,
        "comp_edge_ms": 1253.331133,
        "comm_bytes": 6336,
    },
    "Yan et al. (w3)": {
        "comp_vehicle_ms": 417.604189,
        "comp_edge_ms": 1668.824602,
        "comm_bytes": 4672,
    },
    "Ahmed et al. (w4)": {
        "comp_vehicle_ms": 2506.893294,
        "comp_edge_ms": 2297.272588,
        "comm_bytes": 4736,
    },
    "Proposed (w5)": {
        "comp_vehicle_ms": 417.443973,
        "comp_edge_ms": 417.474015,
        "comm_bytes": 4352,
    },
}

SCHEME_COLORS = {
    "Huang et al. (w1)": "royalblue",
    "Liu et al. (w2)": "darkorange",
    "Yan et al. (w3)": "seagreen",
    "Ahmed et al. (w4)": "crimson",
    "Proposed (w5)": "mediumpurple",
}

DATA_RATE_BPS = 6_000_000
CPU_POWER_W = 10.88
TX_POWER_W = 10.88


def avg(values):
    return sum(values) / len(values) if values else 0.0


def read_simulation_log(csv_path: Path):
    steps = []
    speeds = []
    densities = []
    throughputs = []

    with open(csv_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            if "average_speed_kmph" in row:
                speeds.append(float(row["average_speed_kmph"]))
            elif "speed" in row:
                speeds.append(float(row["speed"]))

            if "density_veh_per_km" in row:
                densities.append(float(row["density_veh_per_km"]))
            elif "density" in row:
                densities.append(float(row["density"]))

            throughputs.append(float(row["throughput"]))

    return {
        "avg_speed": avg(speeds),
        "avg_density": avg(densities),
        "avg_throughput": avg(throughputs),
    }


def communication_delay_ms(comm_bytes: float) -> float:
    return (comm_bytes * 8 / DATA_RATE_BPS) * 1000.0


def total_computation_ms(comp_vehicle: float, comp_edge: float) -> float:
    return comp_vehicle + comp_edge


def total_auth_delay_ms(comp_vehicle: float, comp_edge: float, comm_bytes: float) -> float:
    return total_computation_ms(comp_vehicle, comp_edge) + communication_delay_ms(comm_bytes)


def effective_delay_ms(base_delay_ms: float, avg_density: float, avg_speed_kmph: float) -> float:
    density_factor = 1.0 + (avg_density / 100.0)
    speed_factor = 1.0 + (avg_speed_kmph / 100.0)
    return base_delay_ms * density_factor / speed_factor


def energy_comp_j(comp_ms_total: float) -> float:
    return (comp_ms_total / 1000.0) * CPU_POWER_W


def energy_comm_j(comm_bytes: float) -> float:
    return (comm_bytes * 8 * TX_POWER_W) / DATA_RATE_BPS


def effective_throughput(base_throughput: float, scheme_delay: float, min_delay: float) -> float:
    if scheme_delay <= 0:
        return base_throughput
    return base_throughput * (min_delay / scheme_delay)


def plot_bar(labels, values, ylabel, title, filename):
    colors = [SCHEME_COLORS[label] for label in labels]

    plt.figure(figsize=(11, 6))
    bars = plt.bar(labels, values, color=colors, edgecolor="black", linewidth=1.0)

    plt.ylabel(ylabel, fontsize=12)
    plt.title(title, fontsize=14)
    plt.xticks(rotation=20, ha="right", fontsize=10)
    plt.grid(axis="y", linestyle="--", alpha=0.5)

    for bar, value in zip(bars, values):
        plt.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height(),
            f"{value:.2f}",
            ha="center",
            va="bottom",
            fontsize=9
        )

    plt.tight_layout()
    plt.savefig(filename, dpi=300)
    plt.close()


def generate_all_comparison_graphs():
    csv_path = Path(SIM_LOG_CSV)
    sim_stats = read_simulation_log(csv_path)

    avg_density = sim_stats["avg_density"]
    avg_speed = sim_stats["avg_speed"]
    avg_throughput = sim_stats["avg_throughput"]

    labels = list(SCHEMES.keys())

    computation_values = []
    communication_values = []
    auth_delay_values = []
    sumo_delay_values = []
    energy_values = []
    throughput_values = []

    raw_delays = []
    for label in labels:
        vals = SCHEMES[label]
        raw_delay = total_auth_delay_ms(
            vals["comp_vehicle_ms"],
            vals["comp_edge_ms"],
            vals["comm_bytes"]
        )
        raw_delays.append(raw_delay)

    min_delay = min(raw_delays)

    for label in labels:
        vals = SCHEMES[label]

        comp_total = total_computation_ms(
            vals["comp_vehicle_ms"],
            vals["comp_edge_ms"]
        )

        comm_total = vals["comm_bytes"]

        auth_delay = total_auth_delay_ms(
            vals["comp_vehicle_ms"],
            vals["comp_edge_ms"],
            vals["comm_bytes"]
        )

        sumo_delay = effective_delay_ms(auth_delay, avg_density, avg_speed)
        total_energy = energy_comp_j(comp_total) + energy_comm_j(comm_total)
        throughput = effective_throughput(avg_throughput, auth_delay, min_delay)

        computation_values.append(comp_total)
        communication_values.append(comm_total)
        auth_delay_values.append(auth_delay)
        sumo_delay_values.append(sumo_delay)
        energy_values.append(total_energy)
        throughput_values.append(throughput)

    plot_bar(
        labels,
        computation_values,
        ylabel="Computation Cost (ms)",
        title="Computation Cost Comparison",
        filename="comparison_computation_cost.png"
    )

    plot_bar(
        labels,
        communication_values,
        ylabel="Communication Cost (bytes)",
        title="Communication Cost Comparison",
        filename="comparison_communication_cost.png"
    )

    plot_bar(
        labels,
        auth_delay_values,
        ylabel="Authentication Delay (ms)",
        title="Authentication Delay Comparison",
        filename="comparison_auth_delay.png"
    )

    plot_bar(
        labels,
        sumo_delay_values,
        ylabel="SUMO Practical Delay (ms)",
        title="SUMO Practical Delay Comparison",
        filename="comparison_sumo_delay.png"
    )

    plot_bar(
        labels,
        energy_values,
        ylabel="Energy Consumption (J)",
        title="Energy Consumption Comparison",
        filename="comparison_energy_cost.png"
    )

    plot_bar(
        labels,
        throughput_values,
        ylabel="Throughput (vehicles/step)",
        title="Throughput Comparison",
        filename="comparison_throughput.png"
    )

    print("All corrected graphs generated successfully.")


if __name__ == "__main__":
    generate_all_comparison_graphs()